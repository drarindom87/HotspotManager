package com.example.hotspotmanager

import android.app.Activity
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var networkInfo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        refreshInfo()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 54, 42, 32)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }

        val heading = TextView(this).apply {
            text = "Hotspot Manager"
            textSize = 28f
            setTextColor(0xFF172033.toInt())
            gravity = Gravity.CENTER
        }
        page.addView(heading, matchWrap())

        status = TextView(this).apply {
            text = "Hotspot status: Check in Android settings"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(0xFF46536A.toInt())
            setPadding(0, 28, 0, 20)
        }
        page.addView(status, matchWrap())

        val open = Button(this).apply {
            text = "OPEN HOTSPOT SETTINGS"
            textSize = 16f
            setOnClickListener { openHotspotSettings() }
        }
        page.addView(open, matchWrap())

        networkInfo = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFF263247.toInt())
            setPadding(0, 26, 0, 18)
            text = "Network information"
        }
        page.addView(networkInfo, matchWrap())

        val share = Button(this).apply {
            text = "SHARE HOTSPOT DETAILS"
            setOnClickListener { shareInfo() }
        }
        page.addView(share, matchWrap())

        val note = TextView(this).apply {
            text = "Android 10–16 restrict ordinary apps from silently switching the system hotspot on or off, reading its password, or listing tethered clients. This app opens the official system controls instead of bypassing Android security."
            textSize = 13f
            setTextColor(0xFF68758A.toInt())
            setPadding(0, 30, 0, 0)
        }
        page.addView(note, matchWrap())

        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun openHotspotSettings() {
        val candidates = listOf(
            Intent(Settings.ACTION_TETHER_SETTINGS),
            Intent("android.settings.WIFI_SETTINGS")
        )
        for (intent in candidates) {
            try {
                startActivity(intent)
                return
            } catch (_: Exception) { }
        }
        Toast.makeText(this, "Open Settings > Network & Internet > Hotspot & tethering", Toast.LENGTH_LONG).show()
    }

    private fun refreshInfo() {
        val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val enabled = try { wifi.isWifiEnabled } catch (_: Exception) { false }
        status.text = "Wi-Fi radio: " + if (enabled) "On" else "Off"
        networkInfo.text = "Hotspot controls\nUse the system Hotspot settings to view or change your hotspot name, password, security and connected devices.\n\nThis screen does not expose private hotspot credentials."
    }

    private fun shareInfo() {
        val text = "To join my Wi-Fi hotspot, ask me for the network name and password. I can share them from Android Hotspot settings."
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, "Share hotspot instructions"))
    }
}
