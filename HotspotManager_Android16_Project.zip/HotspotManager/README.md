# Hotspot Manager (Android 16)

A minimal native Android Studio project. It provides a dashboard and a shortcut to the official Android hotspot/tethering settings.

## Important Android limitation
On Android 10–16, ordinary third-party apps cannot generally toggle the system Wi-Fi hotspot, read its configured password, or enumerate tethered clients. Those operations are restricted to privileged/system apps, carrier apps, or device-management/OEM-specific interfaces. This project deliberately uses the official Settings screen rather than claiming unsupported control.

## Build
1. Install Android Studio with Android SDK Platform 36 and JDK 17 or newer.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the debug APK under `app/build/outputs/apk/debug/`.

Package: `com.example.hotspotmanager`
Minimum Android: 8.0 (API 26)
Target SDK: 36 (Android 16)
