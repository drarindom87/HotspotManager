package com.example.voicereminder;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;

public class ReminderService extends Service {
    private static final String CHANNEL="voice_reminder_speaking";
    private static final int NOTIFICATION_ID=4102;
    private TextToSpeech tts;
    @Override public void onCreate(){super.onCreate();createChannel();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String msg=intent==null?null:intent.getStringExtra("reminder_message");
        if(msg==null||msg.trim().isEmpty())msg="Your reminder is due.";
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent content=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        startForeground(NOTIFICATION_ID,nb.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Voice Reminder").setContentText("Announcing: "+msg)
            .setContentIntent(content).setOngoing(true).build());
        final String spoken=msg;
        if(tts!=null){tts.stop();tts.shutdown();tts=null;}
        tts=new TextToSpeech(getApplicationContext(),status->{
            if(status==TextToSpeech.SUCCESS&&tts!=null){
                tts.setLanguage(Locale.getDefault());tts.setSpeechRate(0.95f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                    @Override public void onStart(String id){}
                    @Override public void onDone(String id){stopSelf();}
                    @Override public void onError(String id){stopSelf();}
                });
                tts.speak(spoken,TextToSpeech.QUEUE_FLUSH,null,"voice-reminder-"+startId);
            }else stopSelf();
        });
        return START_NOT_STICKY;
    }
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Speaking reminders",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Notifications while Voice Reminder speaks an alarm");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }
    @Override public void onDestroy(){
        if(tts!=null){tts.stop();tts.shutdown();tts=null;}
        if(Build.VERSION.SDK_INT>=24)stopForeground(STOP_FOREGROUND_REMOVE);else stopForeground(true);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
