package com.example.voicereminder;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class AlarmStore {
    private static final String PREFS="voice_reminder_store", KEY="alarms";
    public static class Reminder {
        public final int id; public final long at; public final String message;
        public Reminder(int id,long at,String message){this.id=id;this.at=at;this.message=message;}
    }
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    public static synchronized List<Reminder> all(Context c){
        List<Reminder> out=new ArrayList<>();
        try{
            JSONArray a=new JSONArray(prefs(c).getString(KEY,"[]"));
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);out.add(new Reminder(o.getInt("id"),o.getLong("at"),o.getString("message")));}
        }catch(Exception ignored){}
        return out;
    }
    public static synchronized void add(Context c,Reminder r){List<Reminder>x=all(c);x.add(r);save(c,x);}
    public static synchronized void remove(Context c,int id){List<Reminder>x=new ArrayList<>();for(Reminder r:all(c))if(r.id!=id)x.add(r);save(c,x);}
    public static synchronized void clear(Context c){save(c,new ArrayList<>());}
    private static void save(Context c,List<Reminder>x){
        JSONArray a=new JSONArray();
        try{for(Reminder r:x){JSONObject o=new JSONObject();o.put("id",r.id);o.put("at",r.at);o.put("message",r.message);a.put(o);}}catch(Exception ignored){}
        prefs(c).edit().putString(KEY,a.toString()).apply();
    }
}
