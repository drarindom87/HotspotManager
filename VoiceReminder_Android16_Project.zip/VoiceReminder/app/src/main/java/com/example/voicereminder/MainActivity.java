package com.example.voicereminder;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Calendar;

public class MainActivity extends Activity {
    private static final int REQUEST_EXACT_ALARM=701, REQUEST_NOTIFICATIONS=702;
    private EditText messageInput, minutesInput;
    private RadioButton timerMode, clockMode;
    private TimePicker timePicker;
    private LinearLayout clockPanel, reminderList;
    private boolean scheduleAfterPermission=false;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        buildUi();
        refreshReminders();
        if(Build.VERSION.SDK_INT>=33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQUEST_NOTIFICATIONS);
        }
    }

    private GradientDrawable shape(int color,int radius){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;
    }
    private TextView label(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private View gap(int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,h));return v;}
    private LinearLayout.LayoutParams full(){return new LinearLayout.LayoutParams(-1,-2);}
    private Button action(String title,int color,int fg){
        Button b=new Button(this);b.setText(title);b.setTextColor(fg);b.setAllCaps(false);
        b.setTextSize(14);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(shape(color,16));return b;
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(20,28,20,28);page.setBackgroundColor(Color.rgb(245,247,251));

        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(label("🔊",30,Color.BLACK,true));
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.setPadding(12,0,0,0);
        titles.addView(label("VOICE REMINDER",22,Color.rgb(20,35,60),true));
        titles.addView(label("Your tasks, spoken on time",13,Color.GRAY,false));header.addView(titles);
        page.addView(header);page.addView(gap(18));

        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(17,17,17,17);panel.setBackground(shape(Color.WHITE,24));
        panel.addView(label("Create a reminder",21,Color.rgb(24,39,67),true));panel.addView(gap(12));
        panel.addView(label("WHAT SHOULD I ANNOUNCE?",12,Color.rgb(90,104,126),true));
        messageInput=new EditText(this);messageInput.setHint("e.g. Call the patient, review reports...");
        messageInput.setTextSize(16);messageInput.setMinLines(3);messageInput.setGravity(Gravity.TOP);
        messageInput.setPadding(13,12,13,12);messageInput.setBackground(shape(Color.rgb(244,247,251),15));
        panel.addView(messageInput,full());panel.addView(gap(12));

        RadioGroup modes=new RadioGroup(this);modes.setOrientation(RadioGroup.HORIZONTAL);
        timerMode=new RadioButton(this);timerMode.setText("Timer");timerMode.setId(View.generateViewId());
        clockMode=new RadioButton(this);clockMode.setText("Clock time");clockMode.setId(View.generateViewId());
        timerMode.setChecked(true);modes.addView(timerMode);modes.addView(clockMode);panel.addView(modes);
        panel.addView(gap(8));

        LinearLayout timerPanel=new LinearLayout(this);timerPanel.setOrientation(LinearLayout.VERTICAL);
        timerPanel.addView(label("ANNOUNCE AFTER (MINUTES)",12,Color.rgb(90,104,126),true));
        minutesInput=new EditText(this);minutesInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        minutesInput.setText("10");minutesInput.setTextSize(18);minutesInput.setPadding(13,9,13,9);
        minutesInput.setBackground(shape(Color.rgb(244,247,251),14));timerPanel.addView(minutesInput,full());
        panel.addView(timerPanel);

        clockPanel=new LinearLayout(this);clockPanel.setOrientation(LinearLayout.VERTICAL);
        clockPanel.addView(label("CHOOSE ANNOUNCEMENT TIME",12,Color.rgb(90,104,126),true));
        timePicker=new TimePicker(this);timePicker.setIs24HourView(false);clockPanel.addView(timePicker);
        clockPanel.setVisibility(View.GONE);panel.addView(clockPanel);

        modes.setOnCheckedChangeListener((g,id)->{
            boolean timer=id==timerMode.getId();
            timerPanel.setVisibility(timer?View.VISIBLE:View.GONE);
            clockPanel.setVisibility(timer?View.GONE:View.VISIBLE);
        });
        panel.addView(gap(12));
        Button schedule=action("SCHEDULE SPOKEN REMINDER",Color.rgb(37,99,235),Color.WHITE);
        schedule.setOnClickListener(v->scheduleReminder());panel.addView(schedule,full());
        page.addView(panel);page.addView(gap(22));

        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(label("Upcoming reminders",19,Color.rgb(24,39,67),true),
            new LinearLayout.LayoutParams(0,-2,1));
        Button clear=action("Clear all",Color.rgb(230,236,245),Color.rgb(55,69,91));
        clear.setOnClickListener(v->confirmClear());row.addView(clear);page.addView(row);page.addView(gap(10));
        reminderList=new LinearLayout(this);reminderList.setOrientation(LinearLayout.VERTICAL);page.addView(reminderList);
        page.addView(gap(15));
        page.addView(label("Exact alarms need Android's Alarms & reminders permission. Spoken output uses your installed Text-to-Speech voice and media volume.",12,Color.GRAY,false));
        scroll.addView(page);setContentView(scroll);
    }

    private void scheduleReminder(){
        String msg=messageInput.getText().toString().trim();
        if(msg.isEmpty()){messageInput.setError("Write what you want announced");return;}
        if(Build.VERSION.SDK_INT>=31){
            AlarmManager am=getSystemService(AlarmManager.class);
            if(!am.canScheduleExactAlarms()){
                scheduleAfterPermission=true;
                new AlertDialog.Builder(this).setTitle("Allow exact alarms")
                    .setMessage("Enable Alarms & reminders for Voice Reminder so it can announce at the selected time.")
                    .setNegativeButton("Not now",(d,w)->scheduleAfterPermission=false)
                    .setPositiveButton("Open settings",(d,w)->{
                        Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:"+getPackageName()));
                        startActivityForResult(i,REQUEST_EXACT_ALARM);
                    }).show();return;
            }
        }
        long when;
        if(timerMode.isChecked()){
            int mins;
            try{mins=Integer.parseInt(minutesInput.getText().toString().trim());}
            catch(Exception e){mins=0;}
            if(mins<1||mins>10080){minutesInput.setError("Enter 1 to 10080 minutes");return;}
            when=System.currentTimeMillis()+mins*60_000L;
        }else{
            Calendar c=Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY,timePicker.getHour());c.set(Calendar.MINUTE,timePicker.getMinute());
            c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
            if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);
            when=c.getTimeInMillis();
        }
        int id=(int)(System.currentTimeMillis()&0x7fffffff);
        AlarmStore.Reminder r=new AlarmStore.Reminder(id,when,msg);
        AlarmStore.add(this,r);AlarmScheduler.schedule(this,r);
        Toast.makeText(this,"Spoken reminder scheduled",Toast.LENGTH_LONG).show();
        messageInput.setText("");refreshReminders();
    }

    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==REQUEST_EXACT_ALARM&&scheduleAfterPermission){
            scheduleAfterPermission=false;scheduleReminder();
        }
    }

    private void confirmClear(){
        new AlertDialog.Builder(this).setTitle("Clear all reminders?")
            .setMessage("All upcoming spoken reminders will be cancelled.")
            .setNegativeButton("Keep",null).setPositiveButton("Clear all",(d,w)->{
                for(AlarmStore.Reminder r:AlarmStore.all(this))AlarmScheduler.cancel(this,r.id);
                AlarmStore.clear(this);refreshReminders();
            }).show();
    }

    private void refreshReminders(){
        if(reminderList==null)return;reminderList.removeAllViews();
        List<AlarmStore.Reminder> items=AlarmStore.all(this);
        if(items.isEmpty()){
            TextView empty=label("No reminders scheduled yet.",14,Color.GRAY,false);
            empty.setPadding(8,15,8,15);reminderList.addView(empty);return;
        }
        for(AlarmStore.Reminder r:items){
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(15,13,15,13);card.setBackground(shape(Color.WHITE,18));
            card.addView(label(DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(new Date(r.at)),
                13,Color.rgb(37,99,235),true));
            card.addView(gap(5));card.addView(label(r.message,16,Color.rgb(28,39,57),true));
            Button cancel=action("Cancel this reminder",Color.rgb(242,245,249),Color.rgb(75,88,109));
            cancel.setOnClickListener(v->{AlarmScheduler.cancel(this,r.id);AlarmStore.remove(this,r.id);refreshReminders();});
            card.addView(gap(6));card.addView(cancel);
            LinearLayout.LayoutParams lp=full();lp.bottomMargin=10;reminderList.addView(card,lp);
        }
    }
}
