package com.example.voicereminder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())){
            long now=System.currentTimeMillis();
            for(AlarmStore.Reminder r:AlarmStore.all(c)){
                if(r.at>now)AlarmScheduler.schedule(c,r);else AlarmStore.remove(c,r.id);
            }
        }
    }
}
