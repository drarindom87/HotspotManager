package com.example.voicereminder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        int id=i.getIntExtra("reminder_id",-1);
        String message=i.getStringExtra("reminder_message");
        if(message==null||message.trim().isEmpty())message="Your reminder is due.";
        if(id!=-1)AlarmStore.remove(c,id);
        Intent s=new Intent(c,ReminderService.class).putExtra("reminder_message",message);
        if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);
    }
}
