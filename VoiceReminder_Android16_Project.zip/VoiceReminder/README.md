# Voice Reminder — Android 16

A native Android app that speaks a user-written reminder at its scheduled time.

## Features
- Timer mode: announce after 1 minute to 7 days
- Clock mode: announce at the selected local time; if today's time has passed, schedule for tomorrow
- Multiple independent reminders
- Android Text-to-Speech announcement using a foreground media-playback service
- Exact alarms using `setExactAndAllowWhileIdle`
- Re-schedules pending reminders after device reboot
- Cancel one reminder or clear all reminders

## Permissions and practical notes
- Android 12+ requires the user to grant **Alarms & reminders / exact alarm** special access. The app opens the system permission screen when needed.
- Android 13+ asks for notification permission so the speaking reminder can show its foreground-service notification.
- Speech uses the installed Android Text-to-Speech engine, the system language/voice, and the phone's media volume. Install/configure a TTS voice and keep media volume audible.
- Exact delivery remains subject to Android's alarm policies, device power management, and user-granted permissions. Do not force-stop the app if reminders must continue.
- This first version schedules one-time reminders, not repeating daily/weekly reminders.

## Build
Use JDK 17, Android SDK Platform 36, and Gradle 8.11.1:
`gradle --no-daemon assembleDebug`

Package: `com.example.voicereminder`
Minimum Android: 8.0 (API 26)
Target SDK: 35
